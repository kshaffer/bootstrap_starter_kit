# bootstrap_starter_kit

A self-contained package for getting started with Bootstrap, containing both a PHP version for shared hosting environments and an HTML/CSS-only version for single-page sites and GitHub Pages. See [bootstrap.pushpullfork.com](https://bootstrap.pushpullfork.com) for details and examples.
